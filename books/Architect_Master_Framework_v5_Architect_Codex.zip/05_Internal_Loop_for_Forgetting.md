# Internal Loop — Memory-Adjusted

Standard loop:
Observe → Model → Simplify → Stress → Align → Evolve

Your version adds:

Observe → Write → Model → Simplify → Stress → Align → Evolve → Record

## Key addition: Write + Record

Write:
- one sentence system model

Record:
- one-line commit or note:
  "Moved recurrence rule to domain engine."

This lets future-you re-enter instantly.

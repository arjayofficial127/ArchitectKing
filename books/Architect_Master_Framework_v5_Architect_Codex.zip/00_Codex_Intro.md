# Codex Intro

This is not a generic architecture guide.

This codex assumes:
- You can understand deep architecture quickly.
- Your main enemy is not complexity — it is recall.

Therefore the system is built around:
- externalized memory
- repeatable loops
- visible anchors

Goal:
Make good architecture happen EVEN when you forget details.

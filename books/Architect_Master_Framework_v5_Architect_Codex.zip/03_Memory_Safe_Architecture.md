# Memory-Safe Architecture (Core Chapter)

Because you forget often, architecture must protect you from recall failure.

## Rule 1 — Externalize decisions
Use lightweight ADRs for every meaningful architectural choice.

## Rule 2 — Name layers explicitly
Use folders that remind you where logic belongs:
- domain/
- ir/
- ui/
- infra/

## Rule 3 — One file = one responsibility
Smaller files are easier to re-enter.

## Rule 4 — Render models (IR)
IR prevents re-remembering layout logic in multiple places.

## Rule 5 — Checklists over memory
Always run a checklist before refactor.

### Memory-safe structure pattern
state/
domain/
ir/
ui/

This structure reminds you automatically.

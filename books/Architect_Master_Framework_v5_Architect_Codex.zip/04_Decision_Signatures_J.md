# Decision Signatures — J

These are choices you naturally make.

## Signature 1 — Zoom Out
You ask for highest-order patterns.
Use it intentionally: start with North Star.

## Signature 2 — Platform Bias
You think in reusable systems.
Guardrail: don't generalize before second real use.

## Signature 3 — Fast Concept Absorption
You understand quickly but may forget specifics.
Countermeasure: write tiny summaries after sessions.

## Signature Rule
Every deep insight must produce one artifact:
- note
- checklist
- template

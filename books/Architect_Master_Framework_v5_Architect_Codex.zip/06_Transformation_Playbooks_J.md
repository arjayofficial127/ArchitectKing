# Transformation Playbooks — Personalized

## Playbook A — 15-minute Re-entry
When returning to a project:

1. Read North Star.
2. Open one-page architect card.
3. Locate state, engine, UI.
4. Find last ADR or note.
5. Only then code.

## Playbook B — Safe Extraction
If logic appears twice:
- extract to domain engine
- keep UI unchanged

## Playbook C — Forget-Proof Refactor
Never perform more than 3 architectural moves in one session.

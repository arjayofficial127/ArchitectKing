# Daily Operating Card (Use Daily)

Before coding (60 seconds):
- What is the North Star?
- What layer am I touching?
- Is this UI or domain?

After coding (60 seconds):
- What changed?
- Write one sentence summary.
- Save it.

If tired:
Stop. Record state. Resume later.

# Architect Profile — J

## Natural strengths
- System-level thinking
- Pattern recognition
- Platform mindset
- High abstraction tolerance

## Natural risks
- Holding too many concepts mentally
- Switching contexts rapidly
- Forgetting decisions made earlier

## Design principle for you
Never rely on memory.
Rely on artifacts.

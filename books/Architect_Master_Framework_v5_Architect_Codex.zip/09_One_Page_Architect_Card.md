# One-Page Architect Card

When stuck:

1. Where is STATE?
2. Where is ENGINE?
3. Is IR missing?
4. Is UI deciding too much?
5. What hurts at 10x?
6. What is the smallest safe evolution?

Mantra:
Move logic toward stability.
Write it down so future-you wins.

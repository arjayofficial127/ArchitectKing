# Architect Codex — v5 (Personalized)
Generated: 2026-02-13 21:31 UTC

This codex is personalized for J.

Core personalization:
- You think in systems and abstractions.
- Your recurring friction: **you forget often**.
- Therefore this codex is built around memory-safe architecture habits.

Reading order:
00_Codex_Intro.md
01_Architect_Profile_J.md
02_North_Star_J.md
03_Memory_Safe_Architecture.md
04_Decision_Signatures_J.md
05_Internal_Loop_for_Forgetting.md
06_Transformation_Playbooks_J.md
07_BaseOfUI_Trajectory_J.md
08_Daily_Operating_Card.md
09_One_Page_Architect_Card.md

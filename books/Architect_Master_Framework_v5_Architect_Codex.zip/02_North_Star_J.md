# Your North Star

Suggested invariant:

**Everything is a capability composed safely over time.**

Interpretation:
- Features are temporary.
- Capabilities are reusable.
- Decisions should reduce future cognitive load.

North Star check:
If a change increases mental load, reconsider.

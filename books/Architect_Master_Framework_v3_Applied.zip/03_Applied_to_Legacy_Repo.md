# Applied Example — Legacy Repo Rescue

Typical legacy symptoms:
- Massive components
- API calls inside UI
- Duplicate logic everywhere

## Rescue Plan (90-minute triage)

1. Identify one stable domain rule.
2. Extract ONLY that rule into engine.
3. Replace two call-sites.
4. Stop.

Repeat daily.

## Rule
Small extractions > big rewrites.

# Applied Example — Calendar System

## Diagnose (Internal Loop)

Observe:
- Modal owns logic
- Time calculations repeated

Model:
- Calendar wants an Engine + IR.

Simplify:
- Move recurrence and validation to engine.

Stress:
- Add booking view
- Add timeline view
- Ensure logic reused

Align:
- Protect time integrity (North Star for calendar)

Evolve (safe order):
1. calendarEngine.ts
2. move validation
3. create RenderableEvent IR
4. update UI to consume IR

## Target Architecture

state/
  events

domain/
  calendarEngine.ts

ir/
  calendarProjection.ts

ui/
  EventModal.tsx
  WeekGrid.tsx

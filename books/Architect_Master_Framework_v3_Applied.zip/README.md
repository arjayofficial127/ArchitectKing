# Architect Master Framework — v3 Applied Edition

Generated: 2026-02-13 21:28 UTC

This edition is practical and execution-focused.

## What this edition adds
- Applied walkthroughs
- Transformation prompts
- Decision trees
- Legacy rescue playbook
- Scaling simulations
- Reusable audit templates

## Suggested reading order

00_How_to_Use_v3.md
01_Applied_to_BaseOfUI.md
02_Applied_to_Calendar_System.md
03_Applied_to_Legacy_Repo.md
04_Transformation_Prompts.md
05_Architect_Decision_Trees.md
06_Refactor_Roadmap_Template.md
07_Scaling_Simulations.md
08_Daily_Architect_Practice.md
09_Checklists_and_Heuristics.md

Use this as a working playbook.

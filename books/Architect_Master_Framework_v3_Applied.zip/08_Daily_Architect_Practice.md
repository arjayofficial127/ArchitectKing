# Daily Architect Practice (10 minutes)

1. Observe one friction point.
2. Write the system model in 3 lines.
3. Identify one move downward (toward domain).
4. Make one small change.
5. Stop.

Consistency beats large refactors.

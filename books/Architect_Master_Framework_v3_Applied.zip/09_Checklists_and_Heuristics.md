# Checklists & Heuristics

## Quick Audit Checklist
- [ ] North Star exists
- [ ] State separated from UI
- [ ] Domain engine present
- [ ] IR exists for complex rendering
- [ ] Metadata used where appropriate
- [ ] UI not deciding business rules

## Heuristic
Move logic toward stability.
UI changes fastest; domain changes slowest.

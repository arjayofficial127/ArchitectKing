# Architect Decision Trees

## Where should logic live?

Does UI need it?
 ├─ No → Domain/Engine
 └─ Yes
     ├─ Is it business rule?
     │   ├─ Yes → Domain
     │   └─ No → UI
     └─ Is it render-only?
         └─ UI/IR

## Should I refactor now?

Build unstable?
 ├─ Yes → stabilize first
 └─ No
     ├─ Logic duplicated?
     │   ├─ Yes → extract
     │   └─ No → wait

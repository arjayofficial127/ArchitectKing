# Transformation Prompts (Reusable)

## Full Architect Audit

"Apply Master Architecture Framework:
- Identify North Star
- Map State/Engine/Projection
- Detect missing IR
- Identify UI-owned business logic
- Propose incremental roadmap"

## Calendar Transformation

"Convert calendar feature to engine-first design:
- extract domain rules
- create renderable IR
- keep UI behavior unchanged"

## Legacy Cleanup

"Find highest-friction logic repeated in >2 places and extract to domain."

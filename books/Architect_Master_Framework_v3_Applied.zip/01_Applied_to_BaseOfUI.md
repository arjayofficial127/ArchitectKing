# Applied Example — BaseOfUI (Platform View)

## North Star (Suggested)
Everything is a capability.

## Current strengths (pattern-aligned)
- Installable app mindset
- Runtime thinking
- Multi-app architecture
- Separation of backend/frontend

## Next evolution (incremental)

### Step 1 — Explicit Domain Engines
Create:
- domain/scheduling
- domain/content
- domain/identity

### Step 2 — Introduce IR per major feature
Example:
RenderableCalendarEvent

### Step 3 — Meta-layer expansion
Move hardcoded app behavior into manifests.

### Step 4 — Observation layer (later)
Track usage:
- most used app
- common flows
- default choices

## Avoid now
- Massive folder renames
- Rewrites
- Premature generic frameworks

# How to Use v3 (Applied Edition)

This version is meant to be USED while building.

## Workflow

1. Open your project.
2. Run the Internal Loop:
   Observe → Model → Simplify → Stress → Align → Evolve
3. Use the decision trees to choose next moves.
4. Apply transformation prompts.
5. Refactor incrementally, never all-at-once.

## Rule
Stabilize first. Refactor second.

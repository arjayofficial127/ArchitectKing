# Refactor Roadmap Template

Project:
Date:

## North Star
(write one sentence)

## Current Frictions
-

## Target Layers
State:
Engine:
IR:
UI:

## Incremental Steps
1.
2.
3.

## Safety Checks
- Build passes after each step.
- No UI behavior changes unless intentional.

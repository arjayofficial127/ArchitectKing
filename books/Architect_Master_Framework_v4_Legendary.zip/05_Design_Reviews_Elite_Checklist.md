# Elite Design Review Checklist

- What is the North Star?
- Where does truth live?
- Is UI deciding business rules?
- Is there a clear domain engine?
- Are render models separated (IR)?
- What are the failure modes?
- How does this evolve in 6 months?

Reject designs that increase cognitive load.

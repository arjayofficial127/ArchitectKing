# Principal Mental Models

## 1. Layers Move at Different Speeds
UI changes fastest.
Domain changes slowest.
Push logic downward.

## 2. Compression of Complexity
Expose small APIs that hide big engines.

## 3. Cost of Change
Every decision changes future cost curves.

## 4. Stability Gradient
Move decisions toward stable layers.

## 5. Optionality
Prefer designs that keep options open.

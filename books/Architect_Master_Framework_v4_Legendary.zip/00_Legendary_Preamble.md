# Legendary Edition — Preamble

Legendary architects optimize for:
- longevity
- clarity under change
- team comprehension
- safe evolution

Rule zero:
A system is successful when it becomes easier to change over time.

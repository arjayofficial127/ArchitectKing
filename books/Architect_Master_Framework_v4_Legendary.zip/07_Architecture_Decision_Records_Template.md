# ADR Template

Title:
Date:
Context:
Decision:
Alternatives Considered:
Consequences:
North Star Alignment:
Rollback Plan:

Keep ADRs short and searchable.

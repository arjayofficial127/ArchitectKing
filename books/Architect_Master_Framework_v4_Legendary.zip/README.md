# Architect Master Framework — v4 Legendary Edition

Generated: 2026-02-13 21:29 UTC

This edition is written like a Staff / Principal Engineer field manual.

## Purpose
Turn architectural thinking into repeatable execution under real-world pressure.

## Contents
00_Legendary_Preamble.md
01_Principal_Mental_Models.md
02_System_Reading_Method.md
03_Architecture_Pressure_Tests.md
04_Refactor_Without_Fear.md
05_Design_Reviews_Elite_Checklist.md
06_Tradeoff_Playbook.md
07_Architecture_Decision_Records_Template.md
08_Incident_to_Architecture_Loop.md
09_AI_Native_Architecture.md
10_Field_Manual_One_Page.md

Use this as your on-the-job companion.

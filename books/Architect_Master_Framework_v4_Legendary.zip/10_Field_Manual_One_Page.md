# One-Page Field Manual

When stuck:

1. What is the North Star?
2. Where is State?
3. Where is Engine?
4. Is IR missing?
5. Is UI too heavy?
6. What hurts at 10x?
7. What's the smallest safe evolution?

Mantra:
Move logic toward stability.

# Refactor Without Fear

Golden rule:
Refactor in slices.

Pattern:
1. Create new engine path.
2. Dual-run old + new briefly.
3. Switch callers incrementally.
4. Delete old path last.

Never refactor everything at once.

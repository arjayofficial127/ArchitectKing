# System Reading Method (10-minute scan)

When opening any repo:

1. Find entry points (app, main, routes)
2. Find data sources
3. Identify where rules actually live
4. Detect gravity violations (logic in UI)
5. Locate duplication

Output:
- one-page mental map.

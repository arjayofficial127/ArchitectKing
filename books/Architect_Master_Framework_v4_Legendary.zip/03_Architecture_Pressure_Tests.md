# Architecture Pressure Tests

Run these before major decisions:

## Scale Test
What breaks at 10x traffic?

## Team Test
Can a new engineer place logic correctly?

## View Multiplication Test
Can this support 3 new UIs without rewriting logic?

## AI Test
Can behavior be modified via metadata safely?

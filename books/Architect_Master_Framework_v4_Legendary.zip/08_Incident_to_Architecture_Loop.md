# Incident → Architecture Loop

Every production incident teaches architecture.

Process:
1. Incident occurs.
2. Identify missing boundary or assumption.
3. Add guardrail in domain engine.
4. Add test or invariant.

Incidents are architecture feedback.

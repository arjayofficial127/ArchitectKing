# AI-Native Architecture

Design so AI can safely interact.

Principles:
- Metadata drives behavior.
- Engines enforce invariants.
- UI remains thin.
- Observation layer learns patterns.

AI edits configuration, not core rules.

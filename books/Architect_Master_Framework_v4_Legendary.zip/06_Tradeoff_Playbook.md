# Tradeoff Playbook

## Speed vs Purity
Ship first, extract later — but leave seams.

## Abstraction Timing
Abstract only after second real use.

## Reuse vs Coupling
Reuse engines, not UI components.

## Simplicity vs Flexibility
Default to simple + extensible seams.

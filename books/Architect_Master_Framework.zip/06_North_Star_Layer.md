# ⭐ North Star Layer

The invariant your system protects.

Examples:
Notion → Everything is a block.
Calendar → Time integrity.

Ask:
If everything changed, what must remain true?

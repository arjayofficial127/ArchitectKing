# ⚡ Architect Instinct Layer

Instinct = pain prediction.

7 Instincts:
1. Gravity (logic falls toward stability)
2. Future Friction
3. Surface Area Reduction
4. Shape Recognition
5. Energy Flow
6. Invariant Protection
7. Evolution Thinking

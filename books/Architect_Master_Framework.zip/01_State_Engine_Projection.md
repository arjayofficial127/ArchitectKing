# 1️⃣ State + Engine + Projection

## State
Truth data. No UI logic.

## Engine
Business rules. Pure logic.

## Projection
UI representation of computed truth.

Rule:
UI must never own business rules.

Flow:
State → Engine → Projection

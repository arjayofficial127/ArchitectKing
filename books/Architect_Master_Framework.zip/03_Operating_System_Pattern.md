# 3️⃣ Operating System Pattern

Build capabilities, not features.

Core System:
- Identity
- Data
- Event System
- Runtime

Domain Engines:
- Scheduling
- Content
- Workflow

Apps = capability compositions.

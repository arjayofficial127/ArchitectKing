# 2️⃣ Invisible Layer (Intermediate Representation)

Engine output should not go directly to UI.

Introduce IR:

State → Engine → IR → UI

IR contains renderable data:
- positions
- flags
- computed properties

Benefits:
- Multiple projections possible
- No duplicated logic
- Stable system core

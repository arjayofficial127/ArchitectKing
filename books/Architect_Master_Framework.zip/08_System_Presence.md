# 🌌 System Presence

Perceiving system as living structure.

Feel:
- Tension
- Flow
- Weight
- Emergence

Ask:
What is this system trying to become?

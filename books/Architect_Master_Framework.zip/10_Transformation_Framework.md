# 🔧 Transformation Framework

When analyzing any project:

1. Identify North Star
2. Map State / Engine / Projection
3. Detect missing IR
4. Detect UI-owned logic
5. Extract domain engines
6. Identify metadata opportunities
7. Identify conscious layer opportunities
8. Refactor incrementally

Never rewrite all at once.

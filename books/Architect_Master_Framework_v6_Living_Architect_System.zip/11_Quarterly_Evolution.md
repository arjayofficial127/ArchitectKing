# Quarterly Evolution (60 minutes)

Zoom out.

## Review
- What capabilities emerged?
- Where is duplication growing?
- What wants to become a domain engine?

## Promote
Move repeated patterns into stable layers.

## Retire
Remove obsolete abstractions.

## Reset
Rewrite North Star if necessary (rare).

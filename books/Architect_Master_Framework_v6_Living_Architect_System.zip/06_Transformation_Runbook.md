# Transformation Runbook (ZIP → Evolution)

When you receive or open any system:

## Step 1 — Intake
Fill Project Intake Template.

## Step 2 — Diagnose
Find:
- UI-owned logic
- duplicated rules
- missing IR

## Step 3 — Choose ONE lane
- Extract domain rule
- Create render model
- Add metadata
- Reduce surface area

## Step 4 — Execute safely
One slice only.

## Step 5 — Record
Add ADR + Daily Log entry.

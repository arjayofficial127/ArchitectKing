# Refactor Sprint Cards

Use one card per short refactor (30–90 minutes).

Card Name:

Goal:
Layer touched:
Risk level (L/M/H):

Steps:
1.
2.
3.

Safety:
- Build passes
- UI unchanged

Done when:
-

# Architecture Radar

Use this weekly to detect drift.

Score 1–5:

- State clarity
- Domain ownership
- UI thinness
- IR usage
- Metadata opportunities
- Testability
- Cognitive load

If any score <= 2:
Plan one small correction next week.

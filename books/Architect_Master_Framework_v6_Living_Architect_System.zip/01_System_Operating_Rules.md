# System Operating Rules

## Rule 1 — Artifacts over memory
If it matters, write it down.

## Rule 2 — Small decisions compound
Record small architecture moves.

## Rule 3 — Incremental evolution
Never rewrite everything.

## Rule 4 — North Star check
Every change must align with your invariant:
"Everything is a capability composed safely over time."

## Rule 5 — Move logic toward stability
UI < IR < Domain < State

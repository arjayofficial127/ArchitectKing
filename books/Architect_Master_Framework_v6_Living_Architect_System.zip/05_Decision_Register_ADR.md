# Decision Register (Light ADR)

Title:
Date:
Context:
Decision:
Alternatives:
Consequences:
North Star alignment:
Rollback:

Keep this short. One screen max.

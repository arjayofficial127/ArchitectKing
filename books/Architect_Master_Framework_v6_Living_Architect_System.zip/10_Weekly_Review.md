# Weekly Review (15 minutes)

1. What changed in architecture?
2. Which decision helped most?
3. What created friction?
4. What should be simplified?
5. Next week's ONE architectural move.

Update Architecture Radar after this.

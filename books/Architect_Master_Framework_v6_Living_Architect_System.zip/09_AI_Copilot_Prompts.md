# AI Copilot Prompts (Living System)

## Architect Audit
"Use Living Architect System v6.
Map State/Engine/IR/UI.
Find one high-leverage evolution."

## Safe Refactor
"Refactor incrementally. Keep behavior identical.
Extract domain logic from UI."

## Re-entry
"Summarize this project for fast re-entry:
North Star, layers, last decisions."

## Decision Check
"Evaluate this change against North Star and cognitive load."

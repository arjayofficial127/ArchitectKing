# Daily Architect Log

Date:

## Observe
What friction did you see today?

## Model
System in 3 lines:

## Decision
What single architectural decision did you make?

## Change
What file/layer changed?

## Record (for future-you)
One sentence summary:

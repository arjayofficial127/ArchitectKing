# Project Intake Template

Project:
Date:
Owner:

## 1) North Star
(one sentence)

## 2) Current Reality
- Entry points:
- Data sources:
- Known pain:

## 3) Layer Map
State:
Domain Engine:
IR (render model):
UI:

## 4) Risks
-

## 5) First Safe Move
(one small evolution)

## 6) Success Signal
(how you will know this helped)

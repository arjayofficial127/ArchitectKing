# 🧠 Living Architect System — v6

Generated: 2026-02-13 21:34 UTC

This is not just a book. It's a **living workflow system**.

## Purpose
Help J continuously apply architecture thinking across projects without relying on memory.

## Core idea
You don't "remember architecture".
You **run a system** that keeps architecture alive.

## Folder map

00_START_HERE.md
01_System_Operating_Rules.md
02_Project_Intake_Template.md
03_Daily_Architect_Log.md
04_Architecture_Radar.md
05_Decision_Register_ADR.md
06_Transformation_Runbook.md
07_Refactor_Sprint_Cards.md
08_Context_Pack_Template.md
09_AI_Copilot_Prompts.md
10_Weekly_Review.md
11_Quarterly_Evolution.md
12_Minimal_Checklists.md

## How to use (short)
1. Create a folder per project.
2. Copy the templates you need.
3. Run the Daily Log + Decision Register.
4. Do weekly review to keep architecture alive.

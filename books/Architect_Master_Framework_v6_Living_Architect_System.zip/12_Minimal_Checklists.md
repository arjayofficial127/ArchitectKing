# Minimal Checklists

## Before coding
- North Star known?
- Layer identified?
- Smallest safe move chosen?

## Before merge
- Domain logic in domain?
- UI still thin?
- Decision recorded?

## Before stopping work
- One sentence log written?

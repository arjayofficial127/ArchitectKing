# Context Pack Template (Send to AI / Future You)

Project:
Goal:

## Architecture Snapshot
North Star:
State:
Engine:
IR:
UI:

## Current Problem
(1-3 sentences)

## Constraints
-

## What NOT to change
-

## Desired outcome
-

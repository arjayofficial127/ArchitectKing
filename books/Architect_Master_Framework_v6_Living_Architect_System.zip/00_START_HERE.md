# START HERE (5 minutes)

This system exists because:

- You think in systems.
- You move fast.
- You forget details later.

The goal is NOT perfect architecture.
The goal is **continuous architectural alignment**.

## First setup

1. Read: 01_System_Operating_Rules.md
2. For any project, create:
   - project-name/
   - copy 02_Project_Intake_Template.md
3. Start a Daily Architect Log.

## Core loop

Observe → Model → Decide → Record → Evolve

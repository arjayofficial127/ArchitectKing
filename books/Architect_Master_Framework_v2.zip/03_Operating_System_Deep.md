
# Operating System Pattern (Deep)

Build capabilities, not features.

Feature Thinking:
"Add booking page."

OS Thinking:
"Add scheduling capability."

Core Capabilities:
- Identity
- Permissions
- Event System
- Runtime
- Storage

Apps become compositions of these capabilities.

Scaling benefit:
New apps reuse runtime instead of rewriting infrastructure.


# Anti-Patterns

1. UI-Driven Business Logic
2. Hardcoded Behavior Instead of Metadata
3. Feature Sprawl
4. Duplicated Calculations
5. Massive Refactor Without Stabilization

Each anti-pattern increases friction under scale.

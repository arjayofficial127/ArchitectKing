
# Meta-Layer Pattern (Deep)

Metadata defines behavior.

Instead of hardcoding branching logic,
engine reads configuration.

Example:

{
  "eventType": "open_slot",
  "visibility": "public",
  "durationDefault": 60
}

Meta-layer allows:
- dynamic system changes
- AI-assisted updates
- runtime configuration

Meta-layer reduces need for redeployment.

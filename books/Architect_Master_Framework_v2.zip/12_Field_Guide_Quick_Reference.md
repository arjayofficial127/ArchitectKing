
# Architect Field Guide

Quick Checks:

- Where is state?
- Where is engine?
- Does UI own logic?
- Is metadata possible?
- What is North Star?
- What will hurt at 10x scale?

If unsure:
Move logic downward toward stability.

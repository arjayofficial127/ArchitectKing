
# State + Engine + Projection (Deep)

STATE
Pure truth. No UI knowledge. No transport logic.

ENGINE
Pure decision logic. Stateless functions preferred.

PROJECTION
How computed results are visualized.

Example (Calendar):

State:
- start
- end
- recurrence rule

Engine:
- resolve occurrences
- validate conflicts

Projection:
- week view
- month view
- agenda list

Violation example:
If modal calculates recurrence logic → UI owns engine.

Corrective refactor:
Extract recurrence logic to calendarEngine.ts.

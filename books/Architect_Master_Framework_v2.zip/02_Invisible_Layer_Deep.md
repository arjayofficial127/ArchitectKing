
# Invisible Layer (Intermediate Representation)

Purpose:
Translate domain decisions into renderable models.

Without IR:
- duplicated layout math
- inconsistent projections
- fragile UI coupling

With IR:
Engine → RenderModel

Example:
RenderableEvent {
  id,
  top,
  height,
  editable,
  displayText
}

All UI components consume RenderableEvent,
not raw domain object.


# System Presence (Deep)

System Presence = holistic perception.

You feel:
- imbalance
- excessive coupling
- growth tension

Architect does not chase bugs.
Architect senses structure drift.

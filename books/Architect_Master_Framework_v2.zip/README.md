# Architect Master Framework — Expanded Edition (v2)

Generated: 2026-02-13 21:26 UTC

This edition expands every concept with:
- Deep explanations
- Practical system examples
- Refactor walkthroughs
- Anti-pattern case studies
- Field reference sheets

Recommended reading order:

00_Philosophy.md
01_State_Engine_Projection_Deep.md
02_Invisible_Layer_Deep.md
03_Operating_System_Deep.md
04_Meta_Layer_Deep.md
05_Conscious_System_Deep.md
06_North_Star_Deep.md
07_Instinct_Deep.md
08_System_Presence_Deep.md
09_Internal_Loop_Deep.md
10_Live_Refactor_Examples.md
11_Anti_Patterns_Case_Studies.md
12_Field_Guide_Quick_Reference.md

Read slowly. Reflect. Apply.

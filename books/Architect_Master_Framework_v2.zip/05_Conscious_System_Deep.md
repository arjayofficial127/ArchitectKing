
# Conscious System Pattern (Deep)

Layer added above metadata.

Observe usage patterns.
Infer behavior preferences.
Adjust defaults or suggest changes.

Example:
User repeatedly sets 30-min meetings.
System adjusts default duration to 30.

Architecture requirement:
Observation must not pollute engine logic.
Separate analytics from domain decisions.


# Architect Instinct (Deep)

Instinct = early detection of future friction.

When code feels heavy,
ask:
- Does it belong lower?
- Will this repeat?
- Is this stable?

Instinct emerges from running internal loop repeatedly.

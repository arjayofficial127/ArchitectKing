
# Live Refactor Example — Calendar System

Problem:
Modal contains recurrence logic.

Step 1 — Observe
UI is heavy.

Step 2 — Model
Calendar needs engine.

Step 3 — Simplify
Extract recurrence to domain/calendarEngine.ts.

Step 4 — Stress
Add booking UI, ensure reuse.

Step 5 — Align
Protect time integrity.

Step 6 — Evolve
Replace direct logic calls gradually.

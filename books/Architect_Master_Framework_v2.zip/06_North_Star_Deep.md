
# North Star Layer (Deep)

North Star = invariant truth.

If refactor violates North Star → reject it.

Example:
If system allows end < start → violates time integrity.

North Star protects coherence during growth.
